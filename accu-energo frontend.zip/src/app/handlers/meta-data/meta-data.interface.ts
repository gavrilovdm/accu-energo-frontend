export interface MetaDataInterface {
  title: string
  description: string
}
