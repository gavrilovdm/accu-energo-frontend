export interface CatalogInterface {
    title: string
    img: string
    url?: object
}
