export interface SliderInterface {
    title: string
    img: string
}
