export interface SeriesInterface {
  id?: number
  title?: string
  description?: string
  text?: string
  img?: string
  brand?: string
}
