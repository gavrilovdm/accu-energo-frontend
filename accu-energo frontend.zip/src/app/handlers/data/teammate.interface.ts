export interface TeammateInterface {
    title: string
    description: string
    number?: string
    mail?: string
    city?: string
}
