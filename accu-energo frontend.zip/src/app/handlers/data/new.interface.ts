export interface NewInterface {
  id?: number
  title?: string
  text?: string
  isActive?: boolean
  date?: string
  url?: string
  description?: string
  image?: string
  images?: string[]
}
