export interface PartnerInterface {
    title: string
    description: string
    link: string
    img: string
}
