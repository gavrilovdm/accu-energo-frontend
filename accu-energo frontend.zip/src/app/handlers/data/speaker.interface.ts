export interface SpeakerInterface {
  title: string
  isActive: boolean
  id?: number
  description?: string
  images?: string[]
  image?: string
}
