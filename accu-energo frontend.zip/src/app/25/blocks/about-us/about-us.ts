import { Component } from "@angular/core";

@Component({
  templateUrl: './about-us.html',
  selector: 'app-about-us'
})
export class AboutUsComponent {}
