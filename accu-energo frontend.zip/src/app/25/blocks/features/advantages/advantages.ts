import {Component} from '@angular/core'

@Component({
  templateUrl: './advantages.html',
  selector: 'app-advantages',
})
export class AdvantagesComponent {
}
