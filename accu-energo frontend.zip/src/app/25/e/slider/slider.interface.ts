export interface SliderInterface {
  img: string
  title: string
  text: string
  urlLink: string
  urlText: string
}
