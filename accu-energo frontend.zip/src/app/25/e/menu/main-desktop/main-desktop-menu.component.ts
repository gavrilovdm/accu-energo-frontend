import {Component} from '@angular/core'

@Component({
    template: `
        
    `,
    selector: 'app-main-desktop-menu'
})

export class MainDesktopMenuComponent {

}
