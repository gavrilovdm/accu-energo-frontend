export interface DocumentInterface {
  title: string
  text: string
  image: string
  fileLink: string
  categories: string[]
}
