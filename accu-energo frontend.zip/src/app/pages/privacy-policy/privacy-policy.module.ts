import {NgModule} from '@angular/core'
import {CommonModule} from '@angular/common'
import {PrivacyPolicyComponent} from './privacy-policy.component'
import {RouterModule} from '@angular/router'
import {MatCardModule} from '@angular/material/card'
import {EOfferBottomModule} from '../../25/blocks/offer-bottom/offer-bottom.module'
import {AdvantagesModule} from '../../25/blocks/features/advantages/advantages.module'
import {PageHeaderModule} from '../../25/e/headers/page-header/page-header.module'

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild([{path: '', component: PrivacyPolicyComponent}]),
        MatCardModule,
        EOfferBottomModule,
        AdvantagesModule,
        PageHeaderModule
    ],
  declarations: [PrivacyPolicyComponent],
  exports: [RouterModule]
})

export class PrivacyPolicyModule {}
