export const environment = {
  production: true,
  imgUrl: '/',
  apiUrl: '/'
}
